<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateProductsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('products', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('dog');
            $table->string('profile',500);
            $table->string('vaccinated',100);   
            $table->string('dewormed');
            $table->string('spayed');
            $table->string('condition');
            $table->string('body');
            $table->string('color');
            $table->string('location');
            $table->string('posted');
            $table->string('adoptionfee');
            $table->string('image');
            $table->string('description');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('products');
    }
}
