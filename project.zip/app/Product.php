<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    protected $fillable=['name','dog','profile','vaccinated','dewormed','spayed',
    'condition','body','color','location','posted','adoptionfee','image','description'];

    

}
