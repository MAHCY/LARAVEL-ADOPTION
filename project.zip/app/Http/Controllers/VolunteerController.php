<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Volunteer; 
Use Session;
class VolunteerController extends Controller
{
    public function create(){
        return view('insertVolunteer');
    }
    public function store(){ 

        $r=request(); 
        $image=$r->file('product-image');        
        $image->move('images',$image->getClientOriginalName());   
        //images is the location                
        $imageName=$image->getClientOriginalName(); 

        $insertComment=Comment::create([    
            'id'=>$r->ID,
            'title'=>$r->title, 
             'date'=>$r->date,
             'contact'=>$r->contact,
             'important'=>$r->important,
             'image'=>$imageName,      
             'detail'=>$r->detail,

        ]);
        Session::flash('success',"Driver add succesful!");        
        Return redirect()->route('show.comment');
    }

    public function show(){
        
        //$products=Product::all();
        $volunteers=DB::table('volunteers')
        ->select('*')
        ->get();  
        return view('volunteer')->with('volunteers',$volunteers);
        // return view('comment')->with('comments',$comments);
    }
}
