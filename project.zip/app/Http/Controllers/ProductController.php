<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use DB;
use App\Product;

Use Session;

class ProductController extends Controller
{

 
    public function __construct(){
        $this->middleware('auth');
    }
    
    public function create(){
        return view('insertProduct') ;
    }
    //Category::all() means "select * from category"
    public function store(){    
        $r=request(); 
        $image=$r->file('product-image');        
        $image->move('images',$image->getClientOriginalName());   
        //images is the location                
        $imageName=$image->getClientOriginalName(); 


        $condition=$r->file('product-image');        
        $condition->move('images',$condition->getClientOriginalName());   
        //images is the location                
        $condition=$condition->getClientOriginalName(); 

        $insertProduct=Product::create([    
            'id'=>$r->ID, 
            'name'=>$r->name, 
            'dog'=>$r->dog, 
            'profile'=>$r->profile, 
            'vaccinated'=>$r->vaccinated,
            'dewormed'=>$r->dewormed,
            'spayed'=>$r->spayed, 
            'condition'=>$r->condition,    
            'body'=>$r->body,     
            'color'=>$r->color,     
            'location'=>$r->location, 
            'posted'=>$r->posted,     
            'adoptionfee'=>$r->adoptionfee,
            'description'=>$r->description,
            'image'=>$imageName,         
        ]);
        Session::flash('success',"Product create succesful!");        
        Return redirect()->route('product');
    }
   
    public function show(){
        
        //$products=Product::all();
        $products=DB::table('products')
        ->select('products.*')
        ->get();  
        return view('showProduct')->with('products',$products);
    }

    public function view(){
        //$products=Product::all();
 
        $products=DB::table('products')
        ->select('*')
        ->get();        
        return view('product')->with('products',$products);
      }
      public function viewProduct($id){
        //select * from Products where id='$id'
         $products =Product::all()->where('id',$id);
         
         return view('productdetail')->with('products',$products);
     }

     public function delete($id){
       
        $products =Product::find($id);
        $products->delete();
        return redirect()->route('all.product');
    }

    public function edit($id){
        //select * from Products where id='$id'
         $products =Product::all()->where('id',$id);
         
         return view('editProduct')->with('products',$products);
     }
}

