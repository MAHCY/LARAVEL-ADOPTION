<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use DB;
use App\Comment; 
Use Session;
class CommentController extends Controller
{
    public function create(){
        return view('insertComment');
    }
    public function store(){ 

        $r=request(); 
        $image=$r->file('product-image');        
        $image->move('images',$image->getClientOriginalName());   
        //images is the location                
        $imageName=$image->getClientOriginalName(); 

        $insertComment=Comment::create([    
            'id'=>$r->ID,
            'name'=>$r->title, 
             'com'=>$r->com,
             'image'=>$imageName,                   
        ]);
        Session::flash('success',"Driver add succesful!");        
        Return redirect()->route('show.comment');
    }

    
    public function show(){
        
        //$products=Product::all();
        $comments=DB::table('comments')
        ->select('*')
        ->get();  
        return view('comment')->with('comments',$comments);
        // return view('comment')->with('comments',$comments);
    }
}
