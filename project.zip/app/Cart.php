<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Cart extends Model
{
    protected $fillable=['userID','name','dog','profile','vaccinated','dewormed','spayed',
    'condition','body','color','location','posted','adoptionfee','description'];

    public function user(){

        return $this->belongsTo('App\User');

    }

}
